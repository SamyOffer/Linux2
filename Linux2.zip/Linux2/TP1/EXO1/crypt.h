char* encrypt (char* msg);

char* decrypt (char* msg);
