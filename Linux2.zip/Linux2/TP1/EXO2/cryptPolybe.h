
#ifndef _CRYPTPOLYBE_H_
#define _CRYPTPOLYBE_H_
char* encryptPolybe(char* msg);
char* decryptPolybe(char* msg);
#endif